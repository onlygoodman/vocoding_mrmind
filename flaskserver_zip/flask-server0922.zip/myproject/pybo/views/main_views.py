from flask import Blueprint, url_for, render_template, request
from werkzeug.utils import redirect



bp = Blueprint('main', __name__, url_prefix='/')
#
# @bp.route('/')
# def startmain():
#     return redirect(url_for('question._list'))

@bp.route('/')
def get_main():
    return render_template('mainpage/mainpage_detail.html')

@bp.route('/detail/<int:question_id>/')
def detail(question_id):
    question = Question.query.get_or_404(question_id)
    return render_template('question/question_detail.html', question=question)

@bp.route('/index')
def index():
    return redirect(url_for('question._list'))

@bp.route('/mychat')
def mychat():
    return redirect(url_for('userinput._list'))

@bp.route('/chat_start')
def chat_start(question=None):
    return redirect(url_for('userinput.chatstart'))

@bp.route('/chat_ing', methods=['POST', 'GET'])
def chat_ing(question=None):
    return redirect(url_for('userinput.chating'))

@bp.route('/usemic', methods=['POST', 'GET'])
def get_stt(question=None):
    return redirect(url_for('stt.recognize_speech_from_mic'))
