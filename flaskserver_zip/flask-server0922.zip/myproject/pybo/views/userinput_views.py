from datetime import datetime
from flask import Blueprint, render_template, request, url_for, g, session
from werkzeug.utils import redirect
from .. import db
from pybo.models import Question, Chatdata
from pybo.model import cosim, gtts
from pybo.forms import QuestionForm, AnswerForm
import sqlite3
import torch

#######for cosim######
from gtts import gTTS
from sentence_transformers import SentenceTransformer, util
import numpy as np
######################

bp = Blueprint('userinput', __name__, url_prefix='/userinput')

@bp.route('/list/')
def _list():
    page = request.args.get('page', type=int, default=1)  # 페이지
    user_id = g.user.username
    # userinput_list = Chatdata.query.get_or_404(user_id)
    userinput_list = Chatdata.query.order_by(Chatdata.create_date.desc()).filter(Chatdata.user_id.like(user_id))
    # userinput_list = Chatdata.query.order_by(userinput)
    userinput_list = userinput_list.paginate(page, per_page=10)
    return render_template('userinput/userinput_list.html', userinput_list=userinput_list)

@bp.route('/chatstart/')
def chatstart(question=None):
    return render_template('userinput/userinput_detail.html', question=question)

@bp.route('/chating/', methods=['POST', 'GET'])
def chating(question=None):

    ## 어떤 http method를 이용해서 전달받았는지를 아는 것이 필요함
    ## 아래에서 보는 바와 같이 어떤 방식으로 넘어왔느냐에 따라서 읽어들이는 방식이 달라짐
    if request.method == 'POST':
        pass

    elif request.method == 'GET':

        ## 넘겨받은 질문
        temp = request.args.get('question')

        temp, temp1 = cosim.cosim(temp)
        gtts.gettts(temp1, 2)

        return render_template('userinput/userinput_detail.html', question=temp, answer=temp1)# wavfile = wavfile)
