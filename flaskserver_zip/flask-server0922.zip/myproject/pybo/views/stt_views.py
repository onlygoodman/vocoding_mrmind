from flask import Blueprint, render_template
import serial
from pybo.model import stt, arduino


bp = Blueprint('stt', __name__, url_prefix='/stt')

from flask import render_template

@bp.route('/micready/')
def micstart(transcript=None):
    return render_template('stt/stt_detail.html', transcript=transcript)


@bp.route("/response", methods=["GET", "POST"])
def recognize_speech_from_mic():
    arduino.connect_arduino_to_flask()
    # transcript, temp1 = stt.getanswer()
    # return render_template('stt/stt_detail.html', transcript=transcript, answer=temp1)

