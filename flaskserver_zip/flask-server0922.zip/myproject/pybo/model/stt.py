import speech_recognition as sr
from pybo.model import cosim, gtts

def getanswer():
    r = sr.Recognizer()
    with sr.Microphone() as source:
        print("Say something!")
        audio = r.listen(source)

        try:
            transcript = r.recognize_google(audio, language="ko-KR")
            print("Google Speech Recognition thinks you said " + transcript)
            transcript, temp1 = cosim.cosim(transcript)

        except sr.UnknownValueError:
            transcript = '다시시도 해보세요'
            temp1 = '오류가 있습니다. 다시 시도해주세요.'
            print("Google Speech Recognition could not understand audio")


        except sr.RequestError as e:
            transcript = '다시시도 해보세요'
            temp1 = '오류가 있습니다. 다시 시도해주세요.'
            print("Could not request results from Google Speech Recognition service; {0}".format(e))

        gtts.gettts(temp1, 1)


        return transcript, temp1

