import threading
# import time
import datetime
# from pybo.model import arduino


def printtest():
    now_time = '({})'.format(datetime.datetime.now().strftime('%y/%m/%d %H:%M:%S'))
    print(now_time + '일정시간 {3}초 마다 반복 출력')

    threading.Timer(3, printtest).start()

if __name__ == '__main__':
    printtest()

