from gtts import gTTS
import time

def gettts(temp1, n):
    tts = gTTS(text=temp1, lang='ko')
    tts.save("C:/projects/myproject/pybo/static/sound/testwav{}.wav".format(n))
    time.sleep(1)
