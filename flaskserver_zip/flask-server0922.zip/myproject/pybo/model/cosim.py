from sentence_transformers import SentenceTransformer, util
import torch
import numpy as np
from .. import db
import sqlite3
from pybo.models import Chatdata
from flask import g
from datetime import datetime


def cosim(transcript):
    conn = sqlite3.connect("c:/projects/myproject/pybo.db", isolation_level=None)
    c = conn.cursor()
    embedder = SentenceTransformer("jhgan/ko-sbert-sts")
    c.execute("SELECT * FROM question")
    qall = c.fetchall()
    qlist = [i[1] for i in qall]

    # Corpus with example sentences
    corpus = qlist
    corpus_embeddings = torch.Tensor(np.load('C:/projects/myproject/corpus_embedding.npy'))

    ## 넘겨받은 질문
    temp = transcript
    queries = [temp]

    # Find the closest 5 sentences of the corpus for each query sentence based on cosine similarity
    top_k = 1
    for query in queries:
        query_embedding = embedder.encode(query, convert_to_tensor=True)
        cos_scores = util.pytorch_cos_sim(query_embedding, corpus_embeddings)[0]
        cos_scores = cos_scores.cpu()

        # We use np.argpartition, to only partially sort the top_k results
        top_results = np.argpartition(-cos_scores, range(top_k))[0:top_k]

        print("\n\n======================\n\n")
        print("Query:", query)
        print("\nTop {} most similar sentences in corpus:".format(top_k))

        # for idx in top_results[0:top_k]:
        #     print(corpus[idx].strip(), "(Score: %.4f)" % (cos_scores[idx]))

    cotemp = corpus[top_results[0]].strip()
    #
    c.execute("SELECT * FROM question WHERE subject=:Subject", {"Subject": cotemp})
    templist = c.fetchall()

    if templist == None:
        temp1 = "잘모르겠어요"

    else :
        temp1 = templist[0][2]

    data = Chatdata(user_id=g.user.username, question=temp, answer=temp1, create_date=datetime.now())
    db.session.add(data)
    db.session.commit()

    return temp, temp1