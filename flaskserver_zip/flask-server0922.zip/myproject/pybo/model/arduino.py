import serial
# from flask import render_template
# from pybo.model import stt
# # #


arduino = serial.Serial('COM3', 9600)

while(True):
    a=arduino.readline()

    # print(a)
    # print(type(a))

    x = a.decode()
    # print(x)
    print(len(x))
    # print(type(x))

    print('')


#
# def connect_arduino_to_flask():
#     arduino = serial.Serial('COM3', 9600)
#
#     button_state = []
#
#     while(True):
#         a=arduino.readline()
#
#         print(a)
#
#         x = a.decode()
#         button_state.append(len(x))
#
#         if len(button_state)>10:
#             button_state = []
#
#         if button_state.count('3') == 6:
#             break
#
#         if button_state.count('3') > 2 :
#             transcript, temp1 = stt.getanswer()
#             return render_template('stt/stt_detail.html', transcript=transcript, answer=temp1)
#
#         else :
#             transcript, temp1 = '아직 준비가 되지 않았습니다.', '버튼을 더 길게 눌러주세요.'
#             return render_template('stt/stt_detail.html', transcript=transcript, answer=temp1)
#
#         print(x)
#         print(len(x))
#         print(type(x))
#
#         print('')